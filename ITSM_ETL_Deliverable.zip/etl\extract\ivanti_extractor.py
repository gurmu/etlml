"""
Ivanti HEAT OData Extractor
----------------------------
Pulls raw OData responses from Ivanti and saves them locally
in a folder structure that mirrors the future Azure Blob Bronze zone.

KEY DESIGN DECISION — why we save the FULL OData envelope, not just value[]:
  The junior's JSON dump stripped the envelope and only saved the value[] array.
  That loses:
    - @odata.count       → total record count (needed to verify completeness)
    - @odata.nextLink    → pagination pointer (needed to resume interrupted runs)
    - All Ivanti system fields not mapped by the junior's schema
    - The extraction provenance (when was this pulled, how many pages, etc.)

  This extractor saves the COMPLETE response exactly as Ivanti returns it,
  wrapped in a thin extraction_meta layer. Nothing from Ivanti is modified.

SCALABILITY:
  - Works for any Ivanti OData entity (Incidents, Problems, Knowledge, etc.)
  - Delta (incremental) extraction via lastModifiedDate cursor
  - Full-load mode for initial seeding or schema-change re-runs
  - Local output now → swap to blob with one env var (OUTPUT_MODE=blob)

USAGE:
  python -m etl.extract.ivanti_extractor --object-types incidents knowledge
  python -m etl.extract.ivanti_extractor --object-types incidents --mode full
  python -m etl.extract.ivanti_extractor --dry-run   # fetch first page only
"""
import argparse
import logging
import os
import time
from datetime import datetime, timezone
from typing import Generator

import requests
from dotenv import load_dotenv

load_dotenv()

from etl import config
from etl.utils.storage import (
    load_cursor,
    save_cursor,
    save_raw_page,
    save_run_summary,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("ivanti_extractor")


# ── HTTP client ────────────────────────────────────────────────────────────────

def _build_headers() -> dict:
    api_key = config.IVANTI_API_KEY
    if not api_key:
        raise EnvironmentError(
            "IVANTI_API_KEY is not set. Add it to your .env file:\n"
            "  IVANTI_API_KEY=your_key_here"
        )
    return {
        "Authorization": f"rest_api_key={api_key}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }


def _get_with_retry(url: str, headers: dict, params: dict) -> dict:
    """
    GET request with exponential backoff retry on 429 / 5xx.
    Raises after MAX_RETRIES consecutive failures.
    """
    last_exc: Exception | None = None
    for attempt, wait in enumerate(
        [0] + config.RETRY_BACKOFF_SECONDS, start=1
    ):
        if wait:
            logger.warning(f"Retry {attempt}/{config.MAX_RETRIES} — waiting {wait}s ...")
            time.sleep(wait)
        try:
            response = requests.get(
                url, headers=headers, params=params,
                timeout=config.REQUEST_TIMEOUT_SECONDS
            )

            if response.status_code == 429:
                retry_after = int(response.headers.get("Retry-After", wait or 5))
                logger.warning(f"Rate limited (429) — Retry-After: {retry_after}s")
                time.sleep(retry_after)
                continue

            if response.status_code >= 500:
                logger.warning(f"Server error {response.status_code} — will retry")
                last_exc = requests.HTTPError(response=response)
                continue

            response.raise_for_status()
            return response.json()

        except requests.RequestException as exc:
            logger.error(f"Request error on attempt {attempt}: {exc}")
            last_exc = exc

    raise RuntimeError(
        f"Extraction failed after {config.MAX_RETRIES} retries. "
        f"Last error: {last_exc}"
    )


# ── Pagination generator ───────────────────────────────────────────────────────

def _paginate(
    entity_set: str,
    headers: dict,
    delta_filter: str | None,
    dry_run: bool,
) -> Generator[tuple[int, dict], None, None]:
    """
    Yields (page_number, raw_odata_response_dict) for every page.

    OData pagination uses $skip + $top (Ivanti HEAT does not support $skipToken).
    Each yielded dict is the COMPLETE API response — envelope + value[].

    Args:
        entity_set : OData entity name e.g. "KnowledgeBase", "Incidents"
        headers    : Auth headers
        delta_filter: OData $filter expression for incremental runs, or None for full load
        dry_run    : If True, stops after the first page
    """
    url = f"{config.IVANTI_BASE_URL}/{entity_set}"
    skip = 0
    page = 1

    while True:
        params: dict = {
            "$top": config.PAGE_SIZE,
            "$skip": skip,
            "$count": "true",   # request @odata.count in response
            "$orderby": "ModifiedDateTime desc",  # newest first
        }

        if delta_filter:
            params["$filter"] = delta_filter

        logger.info(
            f"  Page {page} | entity={entity_set} | $skip={skip} | $top={config.PAGE_SIZE}"
            + (f" | filter: {delta_filter}" if delta_filter else " | FULL LOAD")
        )

        raw = _get_with_retry(url, headers, params)

        records = raw.get("value", [])
        total = raw.get("@odata.count", "unknown")
        logger.info(f"  → {len(records)} records returned (total in Ivanti: {total})")

        yield page, raw

        if dry_run:
            logger.info("  [DRY RUN] Stopping after first page.")
            break

        # Stop if this was the last page
        if len(records) < config.PAGE_SIZE:
            logger.info(f"  Last page reached ({len(records)} < {config.PAGE_SIZE}).")
            break

        skip += config.PAGE_SIZE
        page += 1


# ── Per-object-type extraction ─────────────────────────────────────────────────

def extract_object_type(
    key: str,
    run_cfg: "config.RunConfig",
    headers: dict,
) -> dict:
    """
    Extract all pages for a single Ivanti object type.

    Returns a summary dict with counts and status for the run report.
    """
    entity_set = config.OBJECT_TYPES[key]
    run_date = run_cfg.run_date

    logger.info("=" * 60)
    logger.info(f"EXTRACTING: {key.upper()} (entity={entity_set})")
    logger.info("=" * 60)

    # ── Delta filter ───────────────────────────────────────────────────────────
    delta_filter: str | None = None

    if run_cfg.mode == "incremental":
        cursor = load_cursor(
            object_type=key,
            output_mode=config.OUTPUT_MODE,
            local_root=config.LOCAL_OUTPUT_ROOT,
            blob_container=config.AZURE_STORAGE_CONTAINER,
            storage_account=config.AZURE_STORAGE_ACCOUNT,
        )
        if cursor:
            last_run = cursor["last_run_utc"]
            # OData datetime filter — ISO-8601 with T separator
            delta_filter = f"ModifiedDateTime gt {last_run}"
            logger.info(f"Incremental mode — pulling records modified after: {last_run}")
        else:
            logger.info("No cursor found — running full load for first time.")
    else:
        logger.info("Full-load mode — ignoring cursor, extracting all records.")

    # ── Extraction loop ────────────────────────────────────────────────────────
    pages_saved = 0
    total_records = 0
    extraction_start = datetime.now(timezone.utc)

    try:
        for page_num, raw_response in _paginate(
            entity_set=entity_set,
            headers=headers,
            delta_filter=delta_filter,
            dry_run=run_cfg.dry_run,
        ):
            record_count = len(raw_response.get("value", []))
            total_records += record_count

            if not run_cfg.dry_run:
                save_raw_page(
                    data=raw_response,
                    object_type=key,
                    run_date=run_date,
                    page_number=page_num,
                    output_mode=config.OUTPUT_MODE,
                    local_root=config.LOCAL_OUTPUT_ROOT,
                    blob_container=config.AZURE_STORAGE_CONTAINER,
                    storage_account=config.AZURE_STORAGE_ACCOUNT,
                )
                pages_saved += 1

        # ── Update cursor ONLY after all pages land successfully ───────────────
        if not run_cfg.dry_run:
            save_cursor(
                object_type=key,
                last_run_utc=extraction_start.isoformat(),
                output_mode=config.OUTPUT_MODE,
                local_root=config.LOCAL_OUTPUT_ROOT,
                blob_container=config.AZURE_STORAGE_CONTAINER,
                storage_account=config.AZURE_STORAGE_ACCOUNT,
            )

        status = "success"
        logger.info(
            f"✓ {key}: {total_records} records across {pages_saved} pages saved. "
            f"Cursor updated."
        )

    except Exception as exc:
        status = "failed"
        logger.error(f"✗ {key} FAILED: {exc}")

    elapsed = (datetime.now(timezone.utc) - extraction_start).total_seconds()

    return {
        "object_type": key,
        "entity_set": entity_set,
        "status": status,
        "mode": run_cfg.mode,
        "run_date": run_date,
        "pages_saved": pages_saved,
        "total_records": total_records,
        "elapsed_seconds": round(elapsed, 1),
        "dry_run": run_cfg.dry_run,
    }


# ── Main entry point ───────────────────────────────────────────────────────────

def run(run_cfg: "config.RunConfig") -> None:
    """Run the full extraction for all configured object types."""
    if not run_cfg.run_date:
        run_cfg.run_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    logger.info("╔══════════════════════════════════════════════════════════╗")
    logger.info("║         IVANTI ETL — RAW ODATA EXTRACTOR                ║")
    logger.info("╠══════════════════════════════════════════════════════════╣")
    logger.info(f"║  Run date    : {run_cfg.run_date:<43}║")
    logger.info(f"║  Mode        : {run_cfg.mode:<43}║")
    logger.info(f"║  Output      : {config.OUTPUT_MODE:<43}║")
    logger.info(f"║  Output path : {config.LOCAL_OUTPUT_ROOT:<43}║")
    logger.info(f"║  Object types: {', '.join(run_cfg.object_types):<43}║")
    logger.info(f"║  Dry run     : {str(run_cfg.dry_run):<43}║")
    logger.info("╚══════════════════════════════════════════════════════════╝")

    # Validate object types
    invalid = [k for k in run_cfg.object_types if k not in config.OBJECT_TYPES]
    if invalid:
        raise ValueError(
            f"Unknown object type(s): {invalid}. "
            f"Valid options: {list(config.OBJECT_TYPES.keys())}"
        )

    headers = _build_headers()
    summaries = []

    for key in run_cfg.object_types:
        summary = extract_object_type(key, run_cfg, headers)
        summaries.append(summary)

    # ── Run report ─────────────────────────────────────────────────────────────
    run_report = {
        "run_date": run_cfg.run_date,
        "mode": run_cfg.mode,
        "output_mode": config.OUTPUT_MODE,
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "object_type_results": summaries,
        "overall_status": (
            "success" if all(s["status"] == "success" for s in summaries) else "partial_failure"
        ),
    }

    if not run_cfg.dry_run:
        save_run_summary(
            summary=run_report,
            run_date=run_cfg.run_date,
            output_mode=config.OUTPUT_MODE,
            local_root=config.LOCAL_OUTPUT_ROOT,
            blob_container=config.AZURE_STORAGE_CONTAINER,
            storage_account=config.AZURE_STORAGE_ACCOUNT,
        )

    # ── Final summary ──────────────────────────────────────────────────────────
    logger.info("")
    logger.info("─" * 60)
    logger.info("RUN SUMMARY")
    logger.info("─" * 60)
    for s in summaries:
        status_icon = "✓" if s["status"] == "success" else "✗"
        logger.info(
            f"  {status_icon} {s['object_type']:15s} | "
            f"{s['total_records']:>6} records | "
            f"{s['pages_saved']:>3} pages | "
            f"{s['elapsed_seconds']}s"
        )
    logger.info("─" * 60)
    logger.info(f"  Overall: {run_report['overall_status'].upper()}")
    logger.info(
        f"  Output : {config.LOCAL_OUTPUT_ROOT}/raw/itsm/"
        if config.OUTPUT_MODE == "local"
        else f"  Output : blob://{config.AZURE_STORAGE_CONTAINER}/raw/itsm/"
    )


# ── CLI ────────────────────────────────────────────────────────────────────────

def _parse_args() -> "config.RunConfig":
    parser = argparse.ArgumentParser(
        description="Ivanti HEAT OData Extractor — saves raw responses locally or to Azure Blob"
    )
    parser.add_argument(
        "--object-types",
        nargs="+",
        default=config.DEFAULT_OBJECT_TYPES,
        choices=list(config.OBJECT_TYPES.keys()),
        help="Which Ivanti object types to extract (default: incidents knowledge)",
    )
    parser.add_argument(
        "--mode",
        choices=["incremental", "full"],
        default="incremental",
        help="incremental = delta since last run | full = extract everything (default: incremental)",
    )
    parser.add_argument(
        "--run-date",
        default="",
        help="Override run date (YYYY-MM-DD). Defaults to today.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Fetch first page only — do not save anything. Use to verify connectivity.",
    )

    args = parser.parse_args()
    return config.RunConfig(
        object_types=args.object_types,
        mode=args.mode,
        run_date=args.run_date,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    run_cfg = _parse_args()
    run(run_cfg)
