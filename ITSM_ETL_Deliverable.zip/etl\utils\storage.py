"""
Storage abstraction layer
-------------------------
LOCAL mode : writes JSON files to disk, mirroring Bronze blob folder structure.
BLOB mode  : uploads the same JSON to Azure Blob Storage (same path, same content).

Switching between modes is a single env var change — the extractor never changes.
"""
import json
import os
import logging
from pathlib import Path
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


def _local_path(relative_path: str, root: str) -> Path:
    """Resolve a relative Bronze path to an absolute local path and create dirs."""
    full_path = Path(root) / relative_path
    full_path.parent.mkdir(parents=True, exist_ok=True)
    return full_path


def save_raw_page(
    data: dict,
    object_type: str,
    run_date: str,
    page_number: int,
    output_mode: str,
    local_root: str,
    blob_container: str = "bronze",
    storage_account: str = "",
) -> str:
    """
    Save a single raw OData page response.

    The COMPLETE response dict is saved — envelope and all:
      @odata.context, @odata.count, @odata.nextLink, value[]

    Path pattern (same for local and blob):
      raw/itsm/{object_type}/{run_date}/page_{page_number:03d}.json

    Returns the path/URL where the file was saved.
    """
    relative_path = f"raw/itsm/{object_type}/{run_date}/page_{page_number:03d}.json"

    # Always attach extraction metadata to the envelope before saving.
    # This does NOT modify the original Ivanti fields — it adds a wrapper layer.
    annotated = {
        "_extraction_meta": {
            "object_type": object_type,
            "run_date": run_date,
            "page_number": page_number,
            "extracted_at_utc": datetime.now(timezone.utc).isoformat(),
            "record_count_this_page": len(data.get("value", [])),
            "odata_total_count": data.get("@odata.count", None),
        },
        # Full original OData response — untouched
        "odata_response": data,
    }

    if output_mode == "local":
        return _save_local(annotated, relative_path, local_root)
    elif output_mode == "blob":
        return _save_blob(annotated, relative_path, blob_container, storage_account)
    else:
        raise ValueError(f"Unknown output_mode: {output_mode!r}. Use 'local' or 'blob'.")


def save_cursor(object_type: str, last_run_utc: str, output_mode: str,
                local_root: str, blob_container: str = "bronze",
                storage_account: str = "") -> None:
    """
    Persist the extraction watermark so the next incremental run knows where to start.

    Path: etl-state/cursors/{object_type}.json
    """
    cursor_data = {
        "object_type": object_type,
        "last_run_utc": last_run_utc,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    relative_path = f"etl-state/cursors/{object_type}.json"

    if output_mode == "local":
        _save_local(cursor_data, relative_path, local_root)
    elif output_mode == "blob":
        _save_blob(cursor_data, relative_path, blob_container, storage_account)


def load_cursor(object_type: str, output_mode: str, local_root: str,
                blob_container: str = "bronze", storage_account: str = "") -> dict | None:
    """
    Load the watermark from the last successful run.
    Returns None if no cursor exists (first run = full extraction).
    """
    relative_path = f"etl-state/cursors/{object_type}.json"

    if output_mode == "local":
        path = Path(local_root) / relative_path
        if not path.exists():
            return None
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    elif output_mode == "blob":
        return _load_blob(relative_path, blob_container, storage_account)
    return None


def save_run_summary(summary: dict, run_date: str, output_mode: str,
                     local_root: str, blob_container: str = "bronze",
                     storage_account: str = "") -> None:
    """Save a per-run summary report for monitoring."""
    relative_path = f"etl-state/run_reports/{run_date}_summary.json"
    if output_mode == "local":
        _save_local(summary, relative_path, local_root)
    elif output_mode == "blob":
        _save_blob(summary, relative_path, blob_container, storage_account)


# ── Private helpers ────────────────────────────────────────────────────────────

def _save_local(data: dict, relative_path: str, root: str) -> str:
    full_path = _local_path(relative_path, root)
    with open(full_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    logger.info(f"[LOCAL] Saved → {full_path}")
    return str(full_path)


def _save_blob(data: dict, relative_path: str, container: str,
               storage_account: str) -> str:
    """
    Upload to Azure Blob Storage.
    Uncomment and install azure-storage-blob when cloud engineer provisions storage.
    """
    # from azure.storage.blob import BlobServiceClient
    # from azure.identity import DefaultAzureCredential
    #
    # credential = DefaultAzureCredential()
    # client = BlobServiceClient(
    #     account_url=f"https://{storage_account}.blob.core.usgovcloudapi.net",
    #     credential=credential
    # )
    # blob_client = client.get_blob_client(container=container, blob=relative_path)
    # blob_client.upload_blob(
    #     json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"),
    #     overwrite=True
    # )
    # logger.info(f"[BLOB] Uploaded → {container}/{relative_path}")
    # return f"https://{storage_account}.blob.core.usgovcloudapi.net/{container}/{relative_path}"
    raise NotImplementedError(
        "Blob output not yet active. Set OUTPUT_MODE=local until storage is provisioned."
    )


def _load_blob(relative_path: str, container: str, storage_account: str) -> dict | None:
    raise NotImplementedError("Blob cursor load not yet active.")
