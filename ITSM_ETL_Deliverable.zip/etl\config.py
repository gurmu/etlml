"""
ETL Configuration
-----------------
LOCAL mode  : saves raw OData responses to local disk (current mode — no cloud engineer needed)
BLOB mode   : uploads to Azure Blob Storage (flip OUTPUT_MODE env var when cloud engineer joins)

Nothing else changes between modes. The extractor code is identical.
"""
import os
from dataclasses import dataclass, field
from typing import Literal

# ── Output mode ───────────────────────────────────────────────────────────────
# Set OUTPUT_MODE=blob in your .env when ready to switch to Azure Blob Storage.
OUTPUT_MODE: Literal["local", "blob"] = os.getenv("OUTPUT_MODE", "local")

# ── Ivanti HEAT API ───────────────────────────────────────────────────────────
IVANTI_BASE_URL: str = os.getenv(
    "IVANTI_BASE_URL",
    "https://tss.keypoint.us.com/HEAT/api/odata/businessobject"
)
IVANTI_API_KEY: str = os.getenv("IVANTI_API_KEY", "")

# ── Local output root ─────────────────────────────────────────────────────────
# Mirrors the Bronze blob folder structure exactly.
# When switching to blob, this path becomes the blob container prefix.
LOCAL_OUTPUT_ROOT: str = os.getenv(
    "LOCAL_OUTPUT_ROOT",
    os.path.join(os.path.dirname(__file__), "output")
)

# ── Azure Blob (future — leave blank until cloud engineer provisions) ─────────
AZURE_STORAGE_ACCOUNT: str = os.getenv("AZURE_STORAGE_ACCOUNT", "")
AZURE_STORAGE_CONTAINER: str = os.getenv("AZURE_STORAGE_CONTAINER", "bronze")

# ── Extraction behaviour ──────────────────────────────────────────────────────
PAGE_SIZE: int = int(os.getenv("PAGE_SIZE", "500"))   # OData $top per request
REQUEST_TIMEOUT_SECONDS: int = int(os.getenv("REQUEST_TIMEOUT", "60"))
MAX_RETRIES: int = 3
RETRY_BACKOFF_SECONDS: list[int] = [2, 4, 8]          # exponential backoff

# ── Object types to extract ───────────────────────────────────────────────────
# These are the OData entity set names in Ivanti HEAT.
# Verified from existing codebase: /Incidents, /Employees
# KB is /KnowledgeBase — confirm the exact name from your Ivanti admin if needed.
OBJECT_TYPES: dict[str, str] = {
    "incidents":     "Incidents",
    "problems":      "Problems",
    "changes":       "Changes",
    "knowledge":     "KnowledgeBase",   # adjust if your Ivanti uses different name
    "employees":     "Employees",
}

# Default object types to run (pass --object-types flag to override)
DEFAULT_OBJECT_TYPES: list[str] = ["incidents", "knowledge"]


@dataclass
class RunConfig:
    """Immutable config for a single extraction run."""
    object_types: list[str] = field(default_factory=lambda: list(DEFAULT_OBJECT_TYPES))
    mode: Literal["incremental", "full"] = "incremental"
    run_date: str = ""          # YYYY-MM-DD, auto-set at runtime if blank
    dry_run: bool = False       # if True, fetches first page only — does not save
