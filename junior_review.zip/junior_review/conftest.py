"""
Shared fixtures and fakes for testing ivanti_etl_junior.py.

These fakes stand in for aiohttp (Ivanti API) and BlobServiceClient (Azure Blob)
so tests run instantly, offline, with no real credentials.
"""
import json
import pytest


# ─────────────────────────────────────────────────────────────────────────────
# Fake aiohttp — simulates the Ivanti OData API
# ─────────────────────────────────────────────────────────────────────────────

class FakeAioResponse:
    """Stands in for an aiohttp ClientResponse used as an async context manager."""

    def __init__(self, status: int, json_data=None, text_data: str = "", headers=None):
        self.status = status
        self._json_data = json_data
        self._text_data = text_data
        self.headers = headers or {}

    async def json(self):
        return self._json_data

    async def text(self):
        return self._text_data

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False


class FakeAioSession:
    """
    Stands in for aiohttp.ClientSession.

    Responses are consumed in order on each .get() call. If more calls happen
    than responses provided, the last response is repeated (useful for
    "always rate-limited" tests).
    """

    def __init__(self, responses: list[FakeAioResponse]):
        self._responses = list(responses)
        self.call_count = 0
        self.last_url = None
        self.last_params = None

    def get(self, url, headers=None, params=None, timeout=None):
        self.last_url = url
        self.last_params = params
        idx = min(self.call_count, len(self._responses) - 1)
        response = self._responses[idx]
        self.call_count += 1
        return response

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False


@pytest.fixture
def fake_session_factory():
    """
    Returns a function that builds a fake aiohttp.ClientSession() replacement
    pre-loaded with a fixed sequence of responses.

    Usage:
        session = fake_session_factory([FakeAioResponse(200, {"value": []})])
        monkeypatch.setattr(module.aiohttp, "ClientSession", lambda: session)
    """
    def _build(responses: list[FakeAioResponse]) -> FakeAioSession:
        return FakeAioSession(responses)
    return _build


# ─────────────────────────────────────────────────────────────────────────────
# Fake Azure Blob Storage — simulates BlobServiceClient
# ─────────────────────────────────────────────────────────────────────────────

class FakeBlobClient:
    def __init__(self, store: dict, key: str):
        self._store = store
        self._key = key

    def download_blob(self):
        if self._key not in self._store:
            raise Exception(f"BlobNotFound: {self._key}")
        return FakeBlobDownloader(self._store[self._key])

    def upload_blob(self, data, overwrite=True):
        self._store[self._key] = data if isinstance(data, (str, bytes)) else json.dumps(data)


class FakeBlobDownloader:
    def __init__(self, data):
        self._data = data if isinstance(data, bytes) else data.encode("utf-8")

    def readall(self):
        return self._data


class FakeContainerClient:
    def __init__(self, store: dict, container_name: str):
        self._store = store
        self._container_name = container_name

    def get_blob_client(self, blob_name: str):
        return FakeBlobClient(self._store, f"{self._container_name}/{blob_name}")


class FakeBlobServiceClient:
    """
    In-memory stand-in for azure.storage.blob.BlobServiceClient.

    `store` is a plain dict shared across calls within a test so that
    upload_blob() followed by download_blob() round-trips correctly —
    this is what lets us test get_filter() -> update_cursor() sequences.
    """

    def __init__(self, store: dict):
        self.store = store

    def get_container_client(self, container_name: str):
        return FakeContainerClient(self.store, container_name)

    @classmethod
    def from_connection_string(cls, conn_string, *, _store):
        return cls(store=_store)


@pytest.fixture
def blob_store():
    """A fresh in-memory blob store dict per test."""
    return {}


@pytest.fixture
def patch_blob_service(monkeypatch, blob_store):
    """
    Patches BlobServiceClient.from_connection_string everywhere it's imported
    in the junior module, backed by the shared `blob_store` dict.

    Returns the blob_store dict so tests can pre-seed or inspect blob contents.
    """
    def _apply(module):
        def fake_from_connection_string(conn_string):
            return FakeBlobServiceClient(store=blob_store)

        monkeypatch.setattr(
            module.BlobServiceClient,
            "from_connection_string",
            staticmethod(fake_from_connection_string),
        )
        return blob_store

    return _apply
