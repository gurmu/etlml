"""
This script processes Ivanti records and uploads data to Azure Blob Storage.

"""

import requests
from enum import Enum
import aiohttp
import argparse
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from azure.storage.blob import BlobServiceClient

import asyncio
import os
import logging
import json
import re
from dataclasses import dataclass, asdict
from dotenv import load_dotenv
from typing import Optional
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ============================
# Classes
# ============================

class ObjectType(str, Enum):
    knowledge = "FRS_Knowledges"
    incidents = "Incidents"
    changes = "Changes"


@dataclass
class kb_article:
    title: Optional[str] = None
    keywords: Optional[str] = None
    status: Optional[str] = None
    rec_id: Optional[str] = None
    last_modified_date: Optional[str] = None
    created_date: Optional[str] = None
    retired_date: Optional[str] = None
    expiration_date: Optional[str] = None
    details: Optional[str] = None

    @staticmethod
    def from_json(data: dict):
        return kb_article(
            title=data.get("Title"),
            keywords=data.get("Keywords"),
            status=data.get("Status"),
            rec_id=data.get("RecId"),
            last_modified_date=data.get("LastModDateTime"),
            created_date=data.get("CreatedDateTime"),
            retired_date=data.get("RetiredDate"),
            expiration_date=data.get("ExpirationDate"),
            details=data.get("Details")
        )


@dataclass
class incident:
    incidentnumber: Optional[str] = None
    recID: Optional[str] = None
    status: Optional[str] = None
    createddate: Optional[str] = None
    lastmodifieddate: Optional[str] = None
    resolveddate: Optional[str] = None
    closeddate: Optional[str] = None
    urgency: Optional[str] = None
    subject: Optional[str] = None
    symptom: Optional[str] = None

    @staticmethod
    def from_json(data: dict):
        return incident(
            incidentnumber=data.get("IncidentNumber"),
            recID=data.get("RecId"),
            status=data.get("Status"),
            createddate=data.get("CreatedDateTime"),
            lastmodifieddate=data.get("LastModDateTime"),
            resolveddate=data.get("ResolvedDateTime"),
            closeddate=data.get("ClosedDateTime"),
            urgency=data.get("Urgency"),
            subject=data.get("Subject"),
            symptom=data.get("Symptom"),
        )


@dataclass
class change:
    changenumber: Optional[str] = None
    recID: Optional[str] = None
    status: Optional[str] = None
    type: Optional[str] = None
    createddate: Optional[str] = None
    closeddate: Optional[str] = None
    scheduledstart: Optional[str] = None
    scheduledend: Optional[str] = None
    subject: Optional[str] = None
    description: Optional[str] = None

    @staticmethod
    def from_json(data: dict):
        return change(
            changenumber=data.get("ChangeNumber"),
            recID=data.get("RecId"),
            status=data.get("Status"),
            type=data.get("Type"),
            createddate=data.get("CreatedDateTime"),
            closeddate=data.get("ClosedDateTime"),
            scheduledstart=data.get("ScheduledStartDate"),
            scheduledend=data.get("ScheduledEndDate"),
            subject=data.get("Subject"),
            description=data.get("Description"),
        )


CLASS_MAP = {
    ObjectType.knowledge: kb_article,
    ObjectType.incidents: incident,
    ObjectType.changes: change,
}

CURSOR_MAP = {
    ObjectType.knowledge: "kb_articles",
    ObjectType.incidents: "incidents",
    ObjectType.changes: "changes",
}

CONTAINER_MAP = {
    ObjectType.knowledge: "itsm-knowledgebase",
    ObjectType.incidents: "itsm-incidents",
    ObjectType.changes: "itsm-changes",
}

# ============================
# HELPER FUNCTIONS
# ============================

async def get_records(object_type: ObjectType, config, filter_expr=None, top=100, skip=0) -> dict:
    """
    Fetches records from an Ivanti OData endpoint using an async GET request.

    This function sends a request to the specified OData business object endpoint
    and returns the raw JSON response. It supports server-side paging parameters
    (`$top`, `$skip`) and optional OData filter expressions.

    If the server responds with HTTP 429 (Too Many Requests), the request is
    retried up to 3 times using the server-provided Retry-After header when
    available, or exponential backoff when not. After 3 failed retry attempts,
    an exception is raised.
    """

    record_type = object_type.value if hasattr(object_type, "value") else object_type
    params = {
        "$top": str(top),
        "$skip": str(skip)
    }

    if filter_expr:
        params["$filter"] = filter_expr

    url = f"{config["base_url"]}/api/odata/businessobject/{record_type}"

    async with aiohttp.ClientSession() as session:
        while True:
            async with session.get(url, headers=config["headers"], params=params, timeout=30) as resp:
                if resp.status == 200:
                    return await resp.json()

                if resp.status == 204:
                    logger.info("No records returned")
                    return {"value": []}

                if resp.status == 429:
                    retries += 1
                    if retries > 3:
                        text = await resp.text()
                        raise Exception(f"OData GET failed: {resp.status} - {text}")
                    retry_after = resp.headers.get("Retry-After")
                    if retry_after:
                        delay = int(retry_after)
                    else:
                        delay = 2 ** retries
                    logger.warning(f"Rate limited (429). Retrying in {delay}s "
                                    f"({retries}/{3})...")
                    await asyncio.sleep(delay)
                    continue

                if resp.status != 200:
                    text = await resp.text()
                    raise Exception(f"OData GET failed: {resp.status} - {text}")


async def get_filter(object_type: ObjectType, full_load: bool, config):
    """
    Generate the OData filter expression used for incremental loads.
    """

    if full_load:
        return None
    try:
        # Azure Blob setup
        connection_string = config['conn_string']
        container_name = "etl-state"
        blob_name = f"{CURSOR_MAP.get(object_type)}.json"

        # Connect to blob service
        blob_service = BlobServiceClient.from_connection_string(connection_string)
        container_client = blob_service.get_container_client(container_name)
        blob_client = container_client.get_blob_client(blob_name)

        cursor = blob_client.download_blob().readall()
        cursor = json.loads(cursor.decode("utf-8"))

        last_modified = cursor["LastModDateTime"]
        filter_expression = f"LastModDateTime gt {last_modified}"

        return filter_expression
    except:
        print("Unable to find blob storage cursor file -- All records being extracted")
        return None


async def update_cursor(object_type: ObjectType, new_date: str, last_id: str, config):
    """
    Update the ETL cursor for the given object type in Azure Blob Storage.
    """

    # Azure Blob setup
    connection_string = config['conn_string']
    container_name = "etl-state"
    blob_name = f"{CURSOR_MAP.get(object_type)}.json"

    # Connect to blob service
    blob_service = BlobServiceClient.from_connection_string(connection_string)
    container_client = blob_service.get_container_client(container_name)
    blob_client = container_client.get_blob_client(blob_name)

    # download current cursor
    cursor = blob_client.download_blob().readall()

    # update cursor values
    cursor = json.loads(cursor.decode("utf-8"))

    last_modified_previous = cursor["LastModDateTime"]

    if type(last_modified_previous) != str or datetime.fromisoformat(last_modified_previous) < datetime.fromisoformat(new_date):
        cursor["LastModDateTime"] = new_date
        cursor["Last_ID"] = last_id

        # upload new cursor
        new_json = json.dumps(cursor)
        blob_client.upload_blob(new_json, overwrite=True)


async def trim_html(html_string: str):
    html_string_trimmed = re.sub(r'<(.*?)>', " ", html_string)
    html_string_trimmed = re.sub(r'\t', "", html_string_trimmed)
    html_string_trimmed = re.sub(r'&nbsp;', "", html_string_trimmed)
    html_string_trimmed = re.sub(r"\s+", " ", html_string_trimmed).strip()
    return html_string_trimmed


async def parse_html(object_type: ObjectType, all_articles):
        new_records = [asdict(article) for article in all_articles]

        if object_type.value == 'FRS_Knowledges':
            for rec in new_records:
                rec['details'] = await trim_html(rec['details'])
        return new_records


async def upload_records(object_type: ObjectType, full_load: bool, all_articles, config):
    """
    Upload or append article records to Azure Blob Storage for the given object type.
    """

    # Azure Blob setup
    connection_string = config["conn_string"]
    container_name = f"{CONTAINER_MAP.get(object_type)}"
    print("Using Container:", container_name)
    blob_name = f"{CONTAINER_MAP.get(object_type)}.json"

    # Connect to blob service
    blob_service = BlobServiceClient.from_connection_string(connection_string)
    container_client = blob_service.get_container_client(container_name)
    blob_client = container_client.get_blob_client(blob_name)

    if not full_load:
        try:
            # download current cursor
            records = blob_client.download_blob().readall()
            records = json.loads(records.decode("utf-8"))
        except Exception:
            records = []

        new_records = all_articles
        records.extend(new_records)
        updated_json = json.dumps(records)
        blob_client.upload_blob(updated_json, overwrite=True)

    if full_load:
        records=[]
        new_records = all_articles
        records.extend(new_records)
        updated_json = json.dumps(records)
        blob_client.upload_blob(updated_json, overwrite=True)


async def get_all_records(object_type: ObjectType, full_load: bool, config, limit: int = 0):
    """
    Retrieve all records for a given object type, transform them into their mapped class,
    track the most recent modification timestamp, and update storage and cursor state.
    """

    all_articles = []
    skip = 0
    record_type = object_type.value
    class_type = CLASS_MAP.get(object_type)

    lastmod_date = None
    lastmod_recID = None

    filter_exp = await get_filter(object_type, full_load, config)

    while len(all_articles) < limit or limit == 0:
        if limit == 0:
            page_size = 100
        else:
            page_size = min(100, limit - len(all_articles))

        page = await get_records(
            object_type=object_type,
            filter_expr=filter_exp,
            top=page_size,
            skip=skip,
            config=config
        )

        records = page.get("value", [])
        if not records:
            return []
        classed_recs = [class_type.from_json(r) for r in records]

        for rec in classed_recs:
            if rec.last_modified_date:
                if lastmod_date is None or datetime.fromisoformat(rec.last_modified_date) > datetime.fromisoformat(lastmod_date):
                    lastmod_date = rec.last_modified_date
                    lastmod_recID = rec.rec_id

        all_articles.extend(classed_recs)
        print(f"Fetched {len(records)} articles")

        if len(records) < page_size:
            break


        skip += page_size

    all_articles = await parse_html(object_type, all_articles)
    await upload_records(object_type, full_load, all_articles, config)
    await update_cursor(object_type, lastmod_date, lastmod_recID, config)


async def main(args):
    if args.localrun:
        load_dotenv()

        config = {
            "conn_string": os.getenv("CONN_STRING"),
            "base_url": os.getenv("IVANTI_BASE_URL", ""),
            "api_key": os.getenv("IVANTI_API_KEY", ""),
        }

        if not config["api_key"]:
            logger.warning("IVANTI_API_KEY not set - API calls will fail")

        config["headers"] = {
            "Authorization": f"rest_api_key={config['api_key']}",
            "Accept": "application/json"
    }


    if args.kb:
        await get_all_records(
            object_type=ObjectType.knowledge,
            full_load=args.full_load,
            limit=0,
            config=config)

    if args.incident:
        await get_all_records(
            object_type=ObjectType.incidents,
            full_load=args.full_load,
            limit=0,
            config=config)

    if args.change:
        await get_all_records(
            object_type=ObjectType.changes,
            full_load=args.full_load,
            limit=0,
            config=config)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='A script to incrementally load articles from ITSM')
    parser.add_argument('--full-load', action=argparse.BooleanOptionalAction, help='Run a full load of all items, ignoring cursors last run date.')
    parser.add_argument('--localrun', action=argparse.BooleanOptionalAction, help='Run using local authorization methods')
    parser.add_argument('--kb', action=argparse.BooleanOptionalAction, help='Update Knowledge Base')
    parser.add_argument('--incident', action=argparse.BooleanOptionalAction, help='Update Incidents')
    parser.add_argument('--change', action=argparse.BooleanOptionalAction, help='Update Chnages')
    args = parser.parse_args()
    asyncio.run(main(args))
