"""
Pytest suite for ivanti_etl_junior.py

Run with:
    pip install -r requirements-test.txt
    pytest -v

Tests are grouped into:
  1. Data model tests       (kb_article / incident / change .from_json)
  2. HTML cleaning tests    (trim_html / parse_html)
  3. API client tests       (get_records — pagination, errors, retries)
  4. Cursor / state tests   (get_filter / update_cursor)
  5. Upload tests           (upload_records — full vs incremental)
  6. End-to-end tests       (get_all_records)
  7. Static / portability checks (source-level issues)

Tests marked "EXPECTED BEHAVIOR — WILL FAIL" document real bugs found by
exercising the code. They are written as if the code worked correctly;
since it doesn't yet, they fail and the failure message explains the bug
and the fix needed. This is intentional — it gives the author a precise,
reproducible bug report instead of a vague code review comment.
"""
import json
import re
from datetime import datetime, timedelta

import pytest

from conftest import FakeAioResponse

import ivanti_etl_junior as junior


# ═══════════════════════════════════════════════════════════════════════════
# 1. DATA MODEL TESTS
# ═══════════════════════════════════════════════════════════════════════════

class TestKbArticleFromJson:
    def test_maps_all_fields_correctly(self):
        raw = {
            "Title": "Reset VPN Token",
            "Keywords": "vpn, token, reset",
            "Status": "Published",
            "RecId": "REC-001",
            "LastModDateTime": "2026-06-01T10:00:00",
            "CreatedDateTime": "2026-01-01T08:00:00",
            "RetiredDate": None,
            "ExpirationDate": "2027-01-01T00:00:00",
            "Details": "<p>Step 1</p>",
        }
        article = junior.kb_article.from_json(raw)
        assert article.title == "Reset VPN Token"
        assert article.rec_id == "REC-001"
        assert article.last_modified_date == "2026-06-01T10:00:00"
        assert article.details == "<p>Step 1</p>"

    def test_missing_fields_default_to_none(self):
        article = junior.kb_article.from_json({})
        assert article.title is None
        assert article.rec_id is None
        assert article.details is None

    def test_extra_unknown_fields_are_ignored(self):
        raw = {"Title": "X", "SomeFieldNotInSchema": "ignored"}
        article = junior.kb_article.from_json(raw)
        assert article.title == "X"
        assert not hasattr(article, "SomeFieldNotInSchema")


class TestIncidentFromJson:
    def test_maps_all_fields_correctly(self):
        raw = {
            "IncidentNumber": "INC-100",
            "RecId": "REC-200",
            "Status": "Open",
            "CreatedDateTime": "2026-06-01T00:00:00",
            "LastModDateTime": "2026-06-02T00:00:00",
            "ResolvedDateTime": None,
            "ClosedDateTime": None,
            "Urgency": "High",
            "Subject": "Cannot log in",
            "Symptom": "Password expired",
        }
        rec = junior.incident.from_json(raw)
        assert rec.incidentnumber == "INC-100"
        assert rec.urgency == "High"
        assert rec.symptom == "Password expired"

    def test_missing_fields_default_to_none(self):
        rec = junior.incident.from_json({})
        assert rec.incidentnumber is None
        assert rec.lastmodifieddate is None


class TestChangeFromJson:
    def test_maps_all_fields_correctly(self):
        raw = {
            "ChangeNumber": "CHG-50",
            "RecId": "REC-300",
            "Status": "Approved",
            "Type": "Standard",
            "CreatedDateTime": "2026-05-01T00:00:00",
            "ClosedDateTime": "2026-05-05T00:00:00",
            "ScheduledStartDate": "2026-05-03T00:00:00",
            "ScheduledEndDate": "2026-05-03T02:00:00",
            "Subject": "Patch servers",
            "Description": "Apply June patches",
        }
        rec = junior.change.from_json(raw)
        assert rec.changenumber == "CHG-50"
        assert rec.type == "Standard"

    def test_missing_fields_default_to_none(self):
        rec = junior.change.from_json({})
        assert rec.changenumber is None


# ═══════════════════════════════════════════════════════════════════════════
# 2. HTML CLEANING TESTS
# ═══════════════════════════════════════════════════════════════════════════

class TestTrimHtml:
    @pytest.mark.asyncio
    async def test_strips_html_tags(self):
        result = await junior.trim_html("<p>Hello <b>World</b></p>")
        assert "<" not in result
        assert "Hello" in result and "World" in result

    @pytest.mark.asyncio
    async def test_removes_nbsp_entities(self):
        result = await junior.trim_html("Step 1&nbsp;&nbsp;Step 2")
        assert "&nbsp;" not in result

    @pytest.mark.asyncio
    async def test_collapses_whitespace(self):
        result = await junior.trim_html("<p>Line1</p>\n\n<p>Line2</p>")
        assert "  " not in result  # no double spaces
        assert result == result.strip()

    @pytest.mark.asyncio
    async def test_none_input_raises_typeerror(self):
        """
        EXPECTED BEHAVIOR — WILL FAIL (documents real bug):
        Many KB articles in Ivanti have an empty/null 'Details' field
        (e.g., stub articles, draft articles awaiting content).
        kb_article.from_json() correctly maps this as None via .get("Details"),
        but trim_html() calls re.sub() directly on it with no None-guard,
        crashing the entire pipeline on the first such record.

        FIX NEEDED: trim_html should return "" (or the original value)
        when html_string is None, e.g.:
            if not html_string:
                return ""
        """
        with pytest.raises(TypeError):
            await junior.trim_html(None)


class TestParseHtml:
    @pytest.mark.asyncio
    async def test_trims_details_for_knowledge_articles(self):
        articles = [
            junior.kb_article(title="A", details="<p>Some <b>info</b></p>")
        ]
        result = await junior.parse_html(junior.ObjectType.knowledge, articles)
        assert result[0]["details"] == "Some info"

    @pytest.mark.asyncio
    async def test_does_not_trim_for_incidents(self):
        records = [junior.incident(subject="X", symptom="<p>raw html kept</p>")]
        result = await junior.parse_html(junior.ObjectType.incidents, records)
        assert result[0]["symptom"] == "<p>raw html kept</p>"

    @pytest.mark.asyncio
    async def test_kb_article_with_none_details_crashes(self):
        """
        EXPECTED BEHAVIOR — WILL FAIL (documents real bug):
        Same root cause as test_none_input_raises_typeerror above, but
        exercised through the actual pipeline path (parse_html -> trim_html).
        This is the bug as it will actually manifest in production: a single
        KB article with no Details field aborts the entire batch upload for
        ALL knowledge articles fetched in that run, not just the bad record.
        """
        articles = [
            junior.kb_article(title="Good article", details="<p>fine</p>"),
            junior.kb_article(title="Stub article with no content", details=None),
        ]
        with pytest.raises(TypeError):
            await junior.parse_html(junior.ObjectType.knowledge, articles)


# ═══════════════════════════════════════════════════════════════════════════
# 3. API CLIENT TESTS — get_records()
# ═══════════════════════════════════════════════════════════════════════════

class TestGetRecords:
    @pytest.mark.asyncio
    async def test_200_returns_json_body(self, monkeypatch, fake_session_factory):
        session = fake_session_factory([
            FakeAioResponse(status=200, json_data={"value": [{"RecId": "1"}]})
        ])
        monkeypatch.setattr(junior.aiohttp, "ClientSession", lambda: session)

        config = {"base_url": "https://tss.keypoint.us.com/HEAT", "headers": {}}
        result = await junior.get_records(junior.ObjectType.incidents, config)

        assert result == {"value": [{"RecId": "1"}]}

    @pytest.mark.asyncio
    async def test_builds_correct_url_and_params(self, monkeypatch, fake_session_factory):
        session = fake_session_factory([FakeAioResponse(status=200, json_data={"value": []})])
        monkeypatch.setattr(junior.aiohttp, "ClientSession", lambda: session)

        config = {"base_url": "https://tss.keypoint.us.com/HEAT", "headers": {}}
        await junior.get_records(
            junior.ObjectType.knowledge, config,
            filter_expr="ModifiedDateTime gt 2026-01-01", top=50, skip=100,
        )

        assert session.last_url == "https://tss.keypoint.us.com/HEAT/api/odata/businessobject/FRS_Knowledges"
        assert session.last_params["$top"] == "50"
        assert session.last_params["$skip"] == "100"
        assert session.last_params["$filter"] == "ModifiedDateTime gt 2026-01-01"

    @pytest.mark.asyncio
    async def test_204_returns_empty_value_list(self, monkeypatch, fake_session_factory):
        session = fake_session_factory([FakeAioResponse(status=204)])
        monkeypatch.setattr(junior.aiohttp, "ClientSession", lambda: session)

        config = {"base_url": "https://test", "headers": {}}
        result = await junior.get_records(junior.ObjectType.changes, config)

        assert result == {"value": []}

    @pytest.mark.asyncio
    async def test_500_raises_exception_with_status_and_body(self, monkeypatch, fake_session_factory):
        session = fake_session_factory([
            FakeAioResponse(status=500, text_data="Internal Server Error")
        ])
        monkeypatch.setattr(junior.aiohttp, "ClientSession", lambda: session)

        config = {"base_url": "https://test", "headers": {}}
        with pytest.raises(Exception, match=r"OData GET failed: 500"):
            await junior.get_records(junior.ObjectType.incidents, config)

    @pytest.mark.asyncio
    async def test_401_raises_exception(self, monkeypatch, fake_session_factory):
        session = fake_session_factory([
            FakeAioResponse(status=401, text_data="Invalid API key")
        ])
        monkeypatch.setattr(junior.aiohttp, "ClientSession", lambda: session)

        config = {"base_url": "https://test", "headers": {}}
        with pytest.raises(Exception, match=r"OData GET failed: 401"):
            await junior.get_records(junior.ObjectType.incidents, config)

    @pytest.mark.asyncio
    async def test_429_then_200_eventually_succeeds(self, monkeypatch, fake_session_factory):
        """
        EXPECTED BEHAVIOR — WILL FAIL (documents critical bug):
        Per the function's own docstring: "If the server responds with
        HTTP 429 ... the request is retried up to 3 times ... After 3
        failed retry attempts, an exception is raised."

        ACTUAL BEHAVIOR: `retries` is referenced as `retries += 1` inside
        the 429 branch but is NEVER initialized (no `retries = 0` before
        the while loop). Python raises UnboundLocalError on the very
        first 429 response — the retry logic never executes at all.

        IMPACT: Ivanti throttles this endpoint under normal load. The
        very first rate-limit response crashes the entire extraction run
        instead of backing off, even though backoff logic was written.

        FIX NEEDED: add `retries = 0` immediately before the `while True:` loop.
        """
        responses = [
            FakeAioResponse(status=429, headers={"Retry-After": "0"}),
            FakeAioResponse(status=200, json_data={"value": [{"RecId": "ok"}]}),
        ]
        session = fake_session_factory(responses)
        monkeypatch.setattr(junior.aiohttp, "ClientSession", lambda: session)

        config = {"base_url": "https://test", "headers": {}}
        result = await junior.get_records(junior.ObjectType.incidents, config)

        assert result == {"value": [{"RecId": "ok"}]}

    @pytest.mark.asyncio
    async def test_429_repeated_raises_after_max_retries(self, monkeypatch, fake_session_factory):
        """
        EXPECTED BEHAVIOR — WILL FAIL (same root cause as above):
        After 3 retries, should raise a clear Exception mentioning status 429.
        Actually raises UnboundLocalError on the first attempt — the
        "give up after 3 tries" path is unreachable code right now.
        """
        responses = [FakeAioResponse(status=429, headers={}, text_data="Too Many Requests")] * 6
        session = fake_session_factory(responses)
        monkeypatch.setattr(junior.aiohttp, "ClientSession", lambda: session)

        config = {"base_url": "https://test", "headers": {}}
        with pytest.raises(Exception, match=r"OData GET failed: 429"):
            await junior.get_records(junior.ObjectType.incidents, config)


# ═══════════════════════════════════════════════════════════════════════════
# 4. CURSOR / STATE TESTS — get_filter() / update_cursor()
# ═══════════════════════════════════════════════════════════════════════════

class TestGetFilter:
    @pytest.mark.asyncio
    async def test_full_load_returns_none_without_touching_blob(self):
        # Passing a deliberately broken config — if this doesn't raise,
        # we've proven full_load short-circuits before any blob access.
        result = await junior.get_filter(junior.ObjectType.incidents, True, config={})
        assert result is None

    @pytest.mark.asyncio
    async def test_incremental_with_existing_cursor_builds_filter(
        self, monkeypatch, patch_blob_service
    ):
        store = patch_blob_service(junior)
        store["etl-state/incidents.json"] = json.dumps({
            "LastModDateTime": "2026-06-01T00:00:00",
            "Last_ID": "REC-999",
        })

        config = {"conn_string": "fake"}
        result = await junior.get_filter(junior.ObjectType.incidents, False, config)

        assert result == "LastModDateTime gt 2026-06-01T00:00:00"

    @pytest.mark.asyncio
    async def test_incremental_with_no_cursor_file_returns_none(
        self, monkeypatch, patch_blob_service
    ):
        patch_blob_service(junior)  # empty store — no cursor blob exists
        config = {"conn_string": "fake"}

        result = await junior.get_filter(junior.ObjectType.knowledge, False, config)

        assert result is None

    @pytest.mark.asyncio
    async def test_bare_except_silently_swallows_programming_errors(
        self, monkeypatch, patch_blob_service, capsys
    ):
        """
        EXPECTED BEHAVIOR — WILL FAIL (documents a real design flaw):
        get_filter() wraps the entire blob-read block in a bare `except:`.
        This is meant to handle "cursor file doesn't exist yet, do a full
        load" — but it ALSO silently swallows a missing 'conn_string' key
        (a real misconfiguration), an auth failure, a network timeout, or
        any other programming error, treating all of them identically to
        "first run, no cursor yet."

        This test passes a config MISSING 'conn_string' entirely. The
        correct behavior is that this should be loud — raise, or at minimum
        log an error — because it means the pipeline is misconfigured, not
        that it's a legitimate first run. Instead, get_filter() returns
        None silently (only a print(), never logged, never raised) and the
        caller proceeds as if everything is fine, masquerading a config bug
        as a normal first-time extraction.

        FIX NEEDED: catch specific exceptions only
        (e.g. azure.core.exceptions.ResourceNotFoundError for "blob missing",
        KeyError only around the JSON field lookup) and use
        logger.exception() — or re-raise — for anything else, instead of a
        bare `except: print(...)`.
        """
        patch_blob_service(junior)
        bad_config = {}  # missing 'conn_string' -> KeyError inside get_filter

        result = await junior.get_filter(junior.ObjectType.incidents, False, bad_config)

        # This assertion is what SHOULD be false — the misconfiguration
        # should never produce a clean None as if nothing went wrong.
        assert result is not None, (
            "get_filter() swallowed a missing 'conn_string' config key via "
            "its bare `except:` and returned None as if this were simply "
            "the first run with no cursor file yet. A real misconfiguration "
            "is being silently treated as normal behavior — see captured "
            f"stdout: {capsys.readouterr().out!r}"
        )


class TestUpdateCursor:
    @pytest.mark.asyncio
    async def test_updates_when_new_date_is_later(self, patch_blob_service):
        store = patch_blob_service(junior)
        store["etl-state/incidents.json"] = json.dumps({
            "LastModDateTime": "2026-06-01T00:00:00",
            "Last_ID": "REC-OLD",
        })
        config = {"conn_string": "fake"}

        await junior.update_cursor(
            junior.ObjectType.incidents, "2026-06-15T00:00:00", "REC-NEW", config
        )

        saved = json.loads(store["etl-state/incidents.json"])
        assert saved["LastModDateTime"] == "2026-06-15T00:00:00"
        assert saved["Last_ID"] == "REC-NEW"

    @pytest.mark.asyncio
    async def test_does_not_regress_when_new_date_is_older(self, patch_blob_service):
        store = patch_blob_service(junior)
        store["etl-state/incidents.json"] = json.dumps({
            "LastModDateTime": "2026-06-15T00:00:00",
            "Last_ID": "REC-NEWER",
        })
        config = {"conn_string": "fake"}

        await junior.update_cursor(
            junior.ObjectType.incidents, "2026-06-01T00:00:00", "REC-OLDER", config
        )

        saved = json.loads(store["etl-state/incidents.json"])
        # cursor must NOT move backwards
        assert saved["LastModDateTime"] == "2026-06-15T00:00:00"
        assert saved["Last_ID"] == "REC-NEWER"

    @pytest.mark.asyncio
    async def test_first_ever_run_with_no_existing_cursor_blob(self, patch_blob_service):
        """
        EXPECTED BEHAVIOR — WILL FAIL (documents real bug):
        On the very first run for a brand-new object type (or a brand-new
        environment / fresh storage account), there is no etl-state/{type}.json
        blob yet. get_filter() handles this gracefully (returns None, falls
        back to full load) — but update_cursor() does NOT have the same
        guard. It unconditionally calls blob_client.download_blob(), which
        raises because the blob does not exist, crashing the run AFTER all
        records were already successfully fetched and uploaded.

        IMPACT: First-ever run for any object type always fails at the very
        last step, even though extraction and upload both succeeded. The
        cursor is never created, so every subsequent run also does a full
        reload instead of an incremental one.

        FIX NEEDED: wrap the download_blob() call in get_filter()-style
        try/except, and create the cursor blob if it doesn't exist yet
        instead of assuming it does.
        """
        patch_blob_service(junior)  # empty store — first run ever
        config = {"conn_string": "fake"}

        # Should create the cursor file, not crash.
        await junior.update_cursor(
            junior.ObjectType.incidents, "2026-06-01T00:00:00", "REC-001", config
        )

    @pytest.mark.asyncio
    async def test_none_new_date_raises_typeerror(self, patch_blob_service):
        """
        EXPECTED BEHAVIOR — WILL FAIL (documents real bug):
        get_all_records() can call update_cursor(..., new_date=None, ...)
        when none of the fetched records had a LastModDateTime value
        (lastmod_date stays None throughout the loop). update_cursor() then
        calls datetime.fromisoformat(None), raising TypeError.

        FIX NEEDED: in get_all_records, skip the update_cursor call (or log
        a warning) when lastmod_date is still None after processing all
        pages, instead of passing None through.
        """
        store = patch_blob_service(junior)
        store["etl-state/changes.json"] = json.dumps({
            "LastModDateTime": "2026-06-01T00:00:00",
            "Last_ID": "REC-OLD",
        })
        config = {"conn_string": "fake"}

        with pytest.raises(TypeError):
            await junior.update_cursor(junior.ObjectType.changes, None, None, config)


# ═══════════════════════════════════════════════════════════════════════════
# 5. UPLOAD TESTS — upload_records()
# ═══════════════════════════════════════════════════════════════════════════

class TestUploadRecords:
    @pytest.mark.asyncio
    async def test_full_load_overwrites_existing_blob(self, patch_blob_service):
        store = patch_blob_service(junior)
        store["itsm-incidents/itsm-incidents.json"] = json.dumps(
            [{"incidentnumber": "INC-OLD-DATA-SHOULD-BE-GONE"}]
        )
        config = {"conn_string": "fake"}
        new_records = [{"incidentnumber": "INC-100"}]

        await junior.upload_records(junior.ObjectType.incidents, True, new_records, config)

        saved = json.loads(store["itsm-incidents/itsm-incidents.json"])
        assert saved == [{"incidentnumber": "INC-100"}]

    @pytest.mark.asyncio
    async def test_incremental_appends_to_existing_blob(self, patch_blob_service):
        store = patch_blob_service(junior)
        store["itsm-changes/itsm-changes.json"] = json.dumps(
            [{"changenumber": "CHG-1"}]
        )
        config = {"conn_string": "fake"}
        new_records = [{"changenumber": "CHG-2"}]

        await junior.upload_records(junior.ObjectType.changes, False, new_records, config)

        saved = json.loads(store["itsm-changes/itsm-changes.json"])
        assert saved == [{"changenumber": "CHG-1"}, {"changenumber": "CHG-2"}]

    @pytest.mark.asyncio
    async def test_incremental_with_no_existing_blob_starts_fresh(self, patch_blob_service):
        patch_blob_service(junior)  # empty store
        config = {"conn_string": "fake"}
        new_records = [{"changenumber": "CHG-FIRST"}]

        await junior.upload_records(junior.ObjectType.changes, False, new_records, config)

        # implicitly verifies no crash occurred — the try/except here IS
        # implemented correctly, unlike update_cursor's missing guard above

    @pytest.mark.asyncio
    async def test_duplicate_records_are_not_deduplicated_on_incremental_append(
        self, patch_blob_service
    ):
        """
        EXPECTED BEHAVIOR — WILL FAIL (documents real bug):
        If an incremental run is re-executed after a partial failure (e.g.
        upload succeeded but update_cursor crashed — see
        test_first_ever_run_with_no_existing_cursor_blob above), the SAME
        records will be re-fetched on the next run (cursor wasn't advanced)
        and blindly appended again via list.extend(), creating duplicate
        entries for the same RecId with no dedup check.

        FIX NEEDED: dedupe by rec_id/incidentnumber/changenumber before
        writing, e.g. keyed merge instead of extend().
        """
        store = patch_blob_service(junior)
        store["itsm-incidents/itsm-incidents.json"] = json.dumps(
            [{"incidentnumber": "INC-100", "recID": "REC-1"}]
        )
        config = {"conn_string": "fake"}
        # Same record fetched again due to cursor not having advanced
        duplicate_records = [{"incidentnumber": "INC-100", "recID": "REC-1"}]

        await junior.upload_records(
            junior.ObjectType.incidents, False, duplicate_records, config
        )

        saved = json.loads(store["itsm-incidents/itsm-incidents.json"])
        unique_rec_ids = {r["recID"] for r in saved}
        assert len(saved) == len(unique_rec_ids), (
            f"Expected no duplicates, got {len(saved)} records for "
            f"{len(unique_rec_ids)} unique RecIds: {saved}"
        )


# ═══════════════════════════════════════════════════════════════════════════
# 6. END-TO-END TESTS — get_all_records()
# ═══════════════════════════════════════════════════════════════════════════

class TestGetAllRecords:
    @pytest.mark.asyncio
    async def test_incident_extraction_crashes_on_every_run_attribute_mismatch(
        self, monkeypatch, fake_session_factory, patch_blob_service
    ):
        """
        EXPECTED BEHAVIOR — WILL FAIL (documents the MOST SEVERE bug found —
        this is not an edge case, it breaks 2 of the 3 object types 100% of
        the time):

        get_all_records() tracks the most-recently-modified record with:
            if rec.last_modified_date:
                ...
                lastmod_recID = rec.rec_id

        These attribute names only exist on the `kb_article` dataclass.
        `incident` uses `lastmodifieddate` and `recID` (different names,
        different casing). `change` uses the same `recID` and has no
        last-modified field at all.

        IMPACT: extracting Incidents or Changes — i.e. --incident or
        --change flags — raises AttributeError on the FIRST record of the
        FIRST page, every single time, for every run, full or incremental.
        Only --kb (Knowledge) currently works. This is not a corner case:
        2 of the 3 supported object types are completely non-functional.

        FIX NEEDED: either rename the fields on `incident` and `change` to
        match `kb_article` (last_modified_date / rec_id), or look up the
        correct attribute name per object type instead of hardcoding
        kb_article's field names in shared code.
        """
        patch_blob_service(junior)
        session = fake_session_factory([
            FakeAioResponse(status=200, json_data={"value": [
                {
                    "IncidentNumber": "INC-1",
                    "RecId": "REC-1",
                    "LastModDateTime": "2026-06-01T00:00:00",
                    "Subject": "Cannot log in",
                },
            ]})
        ])
        monkeypatch.setattr(junior.aiohttp, "ClientSession", lambda: session)
        config = {"base_url": "https://test", "headers": {}, "conn_string": "fake"}

        # Should complete successfully — instead raises AttributeError
        await junior.get_all_records(junior.ObjectType.incidents, True, config)

    @pytest.mark.asyncio
    async def test_change_extraction_crashes_on_every_run_attribute_mismatch(
        self, monkeypatch, fake_session_factory, patch_blob_service
    ):
        """Same root cause as the incident test above, for ObjectType.changes."""
        patch_blob_service(junior)
        session = fake_session_factory([
            FakeAioResponse(status=200, json_data={"value": [
                {
                    "ChangeNumber": "CHG-1",
                    "RecId": "REC-1",
                    "Subject": "Patch servers",
                },
            ]})
        ])
        monkeypatch.setattr(junior.aiohttp, "ClientSession", lambda: session)
        config = {"base_url": "https://test", "headers": {}, "conn_string": "fake"}

        await junior.get_all_records(junior.ObjectType.changes, True, config)

    @pytest.mark.asyncio
    async def test_single_page_full_load_uploads_and_sets_cursor(
        self, monkeypatch, fake_session_factory, patch_blob_service
    ):
        store = patch_blob_service(junior)
        session = fake_session_factory([
            FakeAioResponse(status=200, json_data={"value": [
                {
                    "IncidentNumber": "INC-1",
                    "RecId": "REC-1",
                    "LastModDateTime": "2026-06-01T00:00:00",
                    "Subject": "Test",
                },
            ]})
        ])
        monkeypatch.setattr(junior.aiohttp, "ClientSession", lambda: session)
        config = {"base_url": "https://test", "headers": {}, "conn_string": "fake"}

        await junior.get_all_records(junior.ObjectType.incidents, True, config)

        uploaded = json.loads(store["itsm-incidents/itsm-incidents.json"])
        assert len(uploaded) == 1
        assert uploaded[0]["incidentnumber"] == "INC-1"

    @pytest.mark.asyncio
    async def test_multi_page_pagination_collects_all_records(
        self, monkeypatch, fake_session_factory, patch_blob_service
    ):
        """Verifies $skip increments correctly and pagination stops on a short page."""
        patch_blob_service(junior)
        page1 = {"value": [
            {"IncidentNumber": f"INC-{i}", "RecId": f"REC-{i}",
             "LastModDateTime": "2026-06-01T00:00:00"}
            for i in range(100)
        ]}
        page2 = {"value": [
            {"IncidentNumber": "INC-100", "RecId": "REC-100",
             "LastModDateTime": "2026-06-02T00:00:00"}
        ]}
        session = fake_session_factory([
            FakeAioResponse(status=200, json_data=page1),
            FakeAioResponse(status=200, json_data=page2),
        ])
        monkeypatch.setattr(junior.aiohttp, "ClientSession", lambda: session)
        config = {"base_url": "https://test", "headers": {}, "conn_string": "fake"}

        await junior.get_all_records(junior.ObjectType.incidents, True, config)

        assert session.call_count == 2

    @pytest.mark.asyncio
    async def test_empty_first_page_returns_silently_without_uploading(
        self, monkeypatch, fake_session_factory, patch_blob_service
    ):
        """
        EXPECTED BEHAVIOR — WILL FAIL (documents a real bug / surprising behavior):
        When the API returns zero records (e.g. a full reload where the
        object type genuinely has no records, or an over-aggressive delta
        filter), get_all_records returns [] immediately WITHOUT calling
        upload_records or update_cursor at all.

        IMPACT for full_load=True: if an object type previously had records
        and now legitimately has zero (e.g. all archived/purged in Ivanti),
        the existing blob is never cleared — stale data lingers forever
        because upload_records (which does the overwrite) is never reached.

        IMPACT for full_load=False: this is arguably correct (nothing new
        to append) but the cursor also never advances, so the same
        zero-result delta query repeats on every run instead of advancing
        to "now" to keep the filter window from growing unbounded.

        FIX NEEDED: clarify the empty-result contract explicitly:
          - full_load=True + zero records  -> should still call
            upload_records with [] to clear stale data
          - full_load=False + zero records -> should still advance the
            cursor to the current run time to avoid an ever-growing filter
        """
        store = patch_blob_service(junior)
        store["itsm-incidents/itsm-incidents.json"] = json.dumps(
            [{"incidentnumber": "INC-STALE-SHOULD-BE-CLEARED"}]
        )
        session = fake_session_factory([FakeAioResponse(status=200, json_data={"value": []})])
        monkeypatch.setattr(junior.aiohttp, "ClientSession", lambda: session)
        config = {"base_url": "https://test", "headers": {}, "conn_string": "fake"}

        await junior.get_all_records(junior.ObjectType.incidents, True, config)

        saved = json.loads(store["itsm-incidents/itsm-incidents.json"])
        assert saved == [], (
            "Stale blob data was not cleared on a full load with zero "
            f"current records. Blob still contains: {saved}"
        )


# ═══════════════════════════════════════════════════════════════════════════
# 7. STATIC / PORTABILITY CHECKS
# ═══════════════════════════════════════════════════════════════════════════

class TestSourcePortability:
    def test_no_same_quote_nested_fstrings(self):
        """
        EXPECTED BEHAVIOR — WILL FAIL (documents a portability bug):
        Line in get_records():
            url = f"{config["base_url"]}/api/odata/businessobject/{record_type}"
        uses double quotes both for the f-string AND for the dict key
        inside its expression. This is only legal Python syntax on
        3.12+ (PEP 701). Any corporate environment still on 3.9/3.10/3.11
        (very common — many enterprise Azure Functions / App Service
        runtimes still default to 3.10 or 3.11) will fail to even IMPORT
        this module with a SyntaxError, before any test or business logic
        runs at all.

        FIX NEEDED: use a different quote style for the inner expression,
        e.g.  f"{config['base_url']}/api/odata/businessobject/{record_type}"
        """
        source_path = junior.__file__
        with open(source_path, "r", encoding="utf-8") as f:
            source = f.read()

        # Looks for an f-string opened with " that also contains a "..."
        # string literal inside its {} expression — the unsafe pattern.
        unsafe_pattern = re.compile(r'f"\{[^}]*"[^}]*"[^}]*\}')
        matches = unsafe_pattern.findall(source)

        assert not matches, (
            f"Found {len(matches)} f-string(s) using nested double-quotes, "
            f"which require Python 3.12+: {matches}\n"
            "Use single quotes inside the expression instead."
        )

    def test_module_imports_cleanly(self):
        """Sanity check: the module is importable in the CURRENT interpreter."""
        import importlib
        importlib.reload(junior)
